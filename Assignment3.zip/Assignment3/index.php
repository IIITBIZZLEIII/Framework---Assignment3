<?php
use FD\framework\FrontController;
require 'C:\xampp2\Assignment3-backend\config.php';
require rootdir .'\autoload.php';
include ('framework/Route.php');

Route::add('/',function(){
    echo 'Welcome :-)';
});

Route::run('/');
/*if((isset($_GET['controller'])) && ($_GET['controller'] == "Logout"))
{
	$SManager = new SessionManager();
	$SManager->destroy();
}
elseif((isset($_GET['controller'])) && ($_GET['controller'] == "Courses"))
{
	$CController = new CoursesController();
	$CController->run();
}
elseif((isset($_GET['controller'])) && ($_GET['controller'] == "Profile"))
{
	$PController = new ProfileController();
	$PController->run();
}
elseif((isset($_GET['controller'])) && ($_GET['controller'] == "SignUp"))
{
	$SController = new SignupController();
	$SController->run();
}
elseif((isset($_GET['controller'])) && ($_GET['controller'] == "Login"))
{
	$lcontroller = new LoginController();
	$lcontroller->run();
}	
else
{
	$controller = new FrontController();
	$controller->run();
}
*/

FrontController::run();

?>