<?php 
require "autoload.php";
require "config.php";
class Registration
{
	protected $error = [];

	public function run()
	{
		//echo "hello";

		if(isset($_POST))
		{
			$validation = new ValidateController();
			if($validation->SignUpValidation($_POST))
			{
				if($_POST['usrPass'] == $_POST['formRetypePWD'])
				{

					$rawFILE = file_get_contents('data/users.json');
					$decodecFILE = json_decode($rawFILE, true);

					$hashedPassword = password_hash($_POST['usrPass'], PASSWORD_DEFAULT);
					$userName = $_POST['formFullName'];
					$userEmail = $_POST['usrEmail'];
			        $jsonarr = ["Name" => $userName, "Email" => $userEmail, "Password" => $hashedPassword]; 

		        	$decodecFILE['users'][]= $jsonarr;
			        $json = json_encode($decodecFILE);
			        
			        file_put_contents('data/users.json', $json);
			        $qdata  =['controller' => 'Login', 'info' => 'Sign Up Successful !' ];

			        $querystring = http_build_query($qdata);

			        header('Location: index.php' . '?' . $querystring);
				}
				else
				{
					//echo "error";
					$error['pwdmatch'] = 'error occured passwords dont match';
					$SController = new SignupController();
					$SController->run();
				}
			}
			else
			{
				//echo "reg validation error";
				$error['regvalidation'] = 'error occured registration validation failed';
				$SController = new SignupController();
				$SController->run();
			}
	    }
	    else
	    {
	    	//echo "no data submitted";
	    	$error['reg'] = 'error occured no data was submitted';
	    	$SController = new SignupController();
			$SController->run();
	    }
	}	
}

if(isset($_POST['signup']))
	{
		//echo " yo";
		Registration::run();
	}
	else
	{
		header('Location: index.php?controller=SignUp');

	}

?>