<?php
class Registry
{
	private static $instance = null;
	private $value = [];

	private function __contruct()
	{

	}

	private static function instance(): self
	{
		if(is_null(self::$instance))
		{
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function get(string $key): 
	{
		if(isset($this->value[$key]))
		{
			return $this->value[$key];
		}
		return null;
	}
	public function set(string $key, $val)
	{
		$this->value[$key] = $val;
	}
}