<?php
namespace FD\framework;

abstract class PageController_Command_Abstract implements Command_Interface
{
	protected $model = null;
	protected $view = null;

	abstract protected function MakeModel() : Observable_Model;

	abstract protected function MakeView() : View;

	abstract public function run();

	abstract public function execute(CommandContext $context) : bool;
}

?>