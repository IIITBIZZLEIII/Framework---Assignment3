<?php

class DataMapper extends DataMapper_Abstract
{
	private $selectstmt;
	private $updatestmt;
	private $insertstmt;

	public function __construct()
	{
		parent::__construct();
		$this->updatestmt = $this->pdo->prepare("SELECT * FROM users WHERE email=?");
		$this->selectstmt = $this->pdo->prepare("UPDATE users SET email =?, password =? WHERE email=?");
		$this->insertstmt = $this->pdo->prepare("INSERT INTO users(name, email, password) VALUES (?,?,?)");
	}

	protected function doInsert(DomainObject $object)
	{
		$values = [$object->getName()];
		$this->insertstmt->execute($values);
		$id = $this->pdo->lastInsertId();
		$object->setId((int)$id);
	}

	protected function update(DomainObject $object)
	{
		$values = [$object->getName(),$object->getEmail(),$object->getPwd()];
		$this->updatestmt->execute($values);
	}

	public function selectstmt(): \PDOStatement
	{
		return $this->selectstmt;
	}

	protected function doCreateObject(array $raw) : DomainObject
	{
		$obj = new DomainObject((int)$raw['name'],$raw['email'],$raw['password']);
		return $obj;
	}
}

?>