<?php
namespace FD\framework;

interface Command_Interface
{
	public function execute(CommandContext $context) : bool;
}

?>