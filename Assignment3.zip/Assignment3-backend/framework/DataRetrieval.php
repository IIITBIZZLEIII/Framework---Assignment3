<?php

class DataRetrieval extends Model_Abstract
{
	public function getAll() : array
	{
		$jsontoStr = file_get_contents(ddir . '/users.json');
		$jsonarray = json_decode($jsontoStr, true);
		return $jsonarray;
	}

	public function getRecord(string $id) : array
	{
		return [];
	}

	public function loadData(string $data) : array
	{
		return [];
	}

}
?>