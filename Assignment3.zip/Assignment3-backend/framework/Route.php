<?php

class Route{

  private static $routes = Array();
  private static $pathUnknown = null;
  private static $methdNotAllowed = null;

  public static function add($expr, $func, $methd = 'get'){
    array_push(self::$routes,Array(
      'expr' => $expr,
      'function' => $func,
      'method' => $methd
    ));
  }

  public static function pathUnknown($func){
    self::$pathUnknown = $func;
  }

  public static function methdNotAllowed($func){
    self::$methdNotAllowed = $func;
  }

  public static function run($basepath = '/'){

    //Parse current url
    $parsed_url = parse_url($_SERVER['REQUEST_URI']);

    if(isset($parsed_url['path'])){
      $path = $parsed_url['path'];
    }else{
      $path = '/';
    }

    //Get current request method
    $methd = $_SERVER['REQUEST_METHOD'];

    $path_match_found = false;

    $route_match_found = false;

    foreach(self::$routes as $route){

      //If the method matches ,check the path

      //Add basepath to matching string
      if($basepath!=''&&$basepath!='/'){
        $route['expr'] = '('.$basepath.')'.$route['expr'];
      }

      //Add 'find string start' automatically
      $route['expr'] = '^'.$route['expr'];

      //Add 'find string end' automatically
      $route['expr'] = $route['expr'].'$';

      //Check path match	
      if(preg_match('#'.$route['expr'].'#',$path,$matches)){

        $path_match_found = true;

        if(strtolower($method) == strtolower($route['method'])){

          array_shift($matches);

          if($basepath!=''&&$basepath!='/'){
            array_shift($matches);
          }

          call_user_func_array($route['function'], $matches);

          $route_match_found = true;
       
          break;
        }
      }
    }


    if(!$route_match_found){

      if($path_match_found){
        header("HTTP/1.0 405 Method Not Allowed");
        if(self::$methdNotAllowed){
          call_user_func_array(self::$methdNotAllowed, Array($path,$methd));
        }
      }else{
        header("HTTP/1.0 404 Not Found");
        if(self::$pathUnknown){
          call_user_func_array(self::$pathUnknown, Array($path));
        }
      }

    }

  }

}

?>