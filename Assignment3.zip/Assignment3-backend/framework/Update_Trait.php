<?php
namespace FD\framework;

trait Update_Trait
{
	abstract public function update(array $values);
}

?>