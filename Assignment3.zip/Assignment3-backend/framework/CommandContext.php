<?php
namespace FD\framework;

class CommandContext extends CommandContext_Abstract
{
	public function add(string $key, $val)
	{
		$this->data[$key] = $val;
	}

	public function get(string $key) 
	{
		if(isset($this->data[$key]))
		{
			return $this->data[$key];
		}
		return null;
	}

	public function getError() : array
	{
		return [];
	}

	protected function setError($error)
	{

	}
}