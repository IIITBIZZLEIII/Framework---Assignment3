<?php 
namespace FD\framework;
abstract class Model_Abstract
{
	protected $jsondatastore = [];

	abstract public function findAll() : array;
	
	abstract public function findRecord(string $id) : array;

	public function LoadData(string $file) : array
	{
		$filename = basename($file, '.json');
		if(!isset($this->jsondatastore[$filename]) || empty($this->jsondatastore[$filename]))
		{
			$jsonfile = file_get_contents($file);
			$this->jsondatastore[$filename] = json_decode($jsonfile, true);
		}
		return $this->jsondatastore[$filename];
	}

	public static function makeConnection()
	{
		$servername = "localhost";
		$username = "root";
		$password = "";
		$dbname = "mooc";

		$conn = mysqli_connect($servername,$username,$password,$dbname);

		if(!$conn)
		{
			die("Connection Failed: " . mysqli_connect_error());
		}
		return $conn;
	}
}

?>