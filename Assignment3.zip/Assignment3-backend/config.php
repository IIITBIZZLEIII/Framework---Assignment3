<?php

const rootdir = 'c:/xampp2/Assignment3-backend';
const tempdir = rootdir . '/tpl';
const ddir = rootdir . '/data';

?>