<?php

class ProfileModel extends Observable_Model
{

	public function getAll() : array
	{
		$pcdata = $this->LoadData(ddir . '/courses.json');
		//$pidata = $this->LoadData(ddir . '')
		$pcourses = array_slice($pcdata['courses'], 0, 4);
		return ['courses' => $pcourses];
	}

	public function getRecord(string $id) : array
	{
		return [];
	}

}