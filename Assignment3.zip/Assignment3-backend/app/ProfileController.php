<?php 
class ProfileController extends PageController_Abstract
{

	public function run()
	{
		SessionManager::create();
		$SManager = new SessionManager();
		//var_dump($_POST);
		//$SManager->add('user',$_POST['uzrEmail']);

		$pview = new View();
		$pview->setTemplate(tempdir . '/profile.tpl.php');
		$this->setView($pview);
		$this->setModel(new ProfileModel());
		$this->model->attach($this->view);

		//var_dump($_SESSION);
		//checks whether the variable user in the session vairable exist 
		$user = $SManager->getUser('user');
		//var_dump($user);
		if(!($user == NULL) && ($SManager->accessible($user, 'profile')))
		{
			//to acquire the courses the user is registered for
			$pdata = $this->model->getAll();

			//to inform the model to update the data that has been changed
			$this->model->Updatedata($pdata);

			//to inform the model to notify its observers of changes
			$this->model->notify();
		}
		else
		{
			unset($_POST);
			$LController = new LoginController();
			$LController->run();
		}
	}
}