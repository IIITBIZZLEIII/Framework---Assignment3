<?php
namespace Apps\handlers;
use FD\framework\CommandContext;
use FD\framework\Observable_Model;
use FD\framework\PageController_Command_Abstract;
use FD\framework\View;

class IndexController extends PageController_Command_Abstract
{
	private $data = null;

	protected function MakeModel() : Observable_Model
	{
		return new \IndexModel();
	}

	protected function MakeView() : View
	{
		$iview = new View();
		$iview->setTemplate(tempdir . '/index.tpl.php');
		return $iview;
	}
	public function run()
	{
		$this->model = $this->MakeModel();
		$this->view =$this->MakeView();

		$this->model->attach($this->view);
		$idata = $this->model->findAll();

		$this->model->Updatedata($idata);

		$this->model->notify();
	}

	public function execute(CommandContext $context) : bool
	{
		$this->data = $context;
		$this->run();
		return true;
	}
}

?>