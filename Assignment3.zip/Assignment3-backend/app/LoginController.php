<?php
namespace Apps\handlers;
use FD\app\ValidateController;
use FD\framework\SessionManager;
use FD\framework\PageController_Command_Abstract;
use FD\framework\CommandContext;
use FD\framework\Observable_Model;
use FD\framework\View;

class LoginController extends PageController_Command_Abstract
{
	protected function makeView() : View
	{
		$view = new View();
		$view->setTemplate(tempdir . '/login.tpl.php');
		return $view;
	}

	protected function MakeModel() : Observable_Model
	{
		return new \LoginModel();
	}

	public function run()
	{
		if(isset($_POST['signin']))
		{
			$validation = new ValidateController();
			if($validation->run() == true)
			{
				echo "validate working";
				SessionManager::create();
				$SManager = new SessionManager();
				//var_dump($_POST);
				$SManager->add('user',$_POST['uzrEmail']);
				/*$PController = new ProfileController();
				$PController->run();*/
				header('Location:index.php?controller=Profile');
			}
			else
			{
				echo "error occured during validation";
				unset($_POST);
				$this->setView = $this->makeView();
				$this->setView->display();
			}
		}
		else
		{
			unset($_POST);
			$this->setView = $this->makeView();
			$this->setView->display();
		}
	}

	public function execute(CommandContext $context) : bool
	{
		$this->data = $context;
		$this->run();
		return true;
	}
}

?>