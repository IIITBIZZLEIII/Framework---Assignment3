<?php
class ValidateController extends PageController_Abstract
{
	private $error = [];
	protected function makeView() : View
	{
		$blnkview = new View();
		return $blnkview;
	}

	public function run()
	{
		if($this->CredentialsValid($_POST) == true)
		{
			//echo "validate working";
			return true;
		}
		else
		{
			//echo "error occured during validation";
			$this->error['validation'] = 'error occured during validation';
			return false;
		}
	}

	function CredentialsValid(array $user_info) : bool
	{
		$data = new DataRetrieval();
		$jsondata = $data->getAll();
		//var_dump($jsondata);
		if(empty($jsondata))
		{
			$this->error['Data'] = 'No data received';
			return false;
		}
		else
		{
			$arraykey = array_search($user_info['uzrEmail'],array_column($jsondata['users'], 'Email'));
			if($jsondata['users'][$arraykey]['Email'] == $user_info['uzrEmail'])
			{
				$hashpass = $jsondata['users'][$arraykey]['Password'];
			}
			var_dump($hashpass);
			var_dump($jsondata);
			$email_valid = $this->EmailValid($user_info['uzrEmail']);
			$password_valid = $this->PasswordValid($user_info['uzrPass']);
			$hashstringpassvalid = $this->verifyHashStringPass($user_info['uzrPass'],$hashpass);
			
			if(!$email_valid || !$password_valid)
			{
				$this->error['Format'] = 'Email or Password or format incorrect';
				return false;
			}	
			if(!$hashstringpassvalid)
			{
				$this->error['PassHash'] = 'Password after checking is incorrect !';
				return false;
			}
			return true;
		}
	}

	function SignUpValidation(array $newuser) : bool
	{
		//var_dump($newuser);
		$email_valid = $this->EmailValid($newuser['usrEmail']);
		$password_valid = $this->PasswordValid($newuser['usrPass']);
		$name_valid = $this->NameValid($newuser['formFullName']);

		if(!$email_valid)
		{
			//echo"name error";
			$this->error['Format'] = 'Email format incorrect';
			return false;
		}
		if(!$password_valid)
		{
			//echo "password error";
			$this->error['Format'] = 'Password format incorrect';
			return false;
		}
		if(!$name_valid)
		{
			//echo "Name error";
			$this->error['Format'] = 'Name format incorrect';
			return false;
		}
		return true;	
	}

	function EmailValid(string $email): bool
	{
		if(filter_var($email,FILTER_VALIDATE_EMAIL))
		{
			return true;
		}
		$this->error['Email'] = 'Incorrect Email Format !';
		return false;
	}

	function PasswordValid(string $password) : bool
	{
		$pattern = "/^(?=.{10,}$)(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9]).*$/";
		if(strlen($password) < 10)
		{
			$this->error['Password'] = "password length error";
			return false;
		}
		if(preg_match($pattern, $password))
		{

			return true;
		}		
		$this->error['Password'] = 'Incorrect Password Format !';
		return false;
	}
	function verifyHashStringPass(string $password, $hashpass) : bool
	{
		if(password_verify($password, $hashpass))
		{
			return true;
		}		
		else
		{
			$this->error['Password'] = 'password entered does not match hashed password';
			return false;
		}
	}
	function NameValid(string $name) : bool
	{
		if($name == "")
		{
			$this->err['Name'] = 'Name is blank, try again';
			return false;
		}
		else
		{
			if((strpbrk($name, 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ ')) !== FALSE)
			{
				return true;
			}
			else
			{
				$this->err['Name'] = 'Name must only include alphabetic characters';
				return false;
			}
		}
	}


}