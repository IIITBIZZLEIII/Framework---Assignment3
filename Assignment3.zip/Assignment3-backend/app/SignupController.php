<?php 
class SignupController extends PageController_Abstract
{
	protected function makeView() : View
	{
		$suview = new View();
		$suview->setTemplate(tempdir . '/signup.tpl.php');
		return $suview;
	}

	public function run()
	{
		$this->setView = $this->makeView();
		$this->setView->display();		
	}
}
?>