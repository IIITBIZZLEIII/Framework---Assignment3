<?php

use PHPUnit\Framework\TestCase;
require 'framework/SessionManager.php';

class SessionManagerTest extends TestCase //checks if the sessionmanager object was created
{
	public function testSessionObjectIsCreated() : void
	{
		$this->assertIsObject(new SessionManager);
	}

	public function testSessionManagerHasStaticMethodCreate() : void
	{
		$method = new ReflectionMethod('SessionManager', 'create');
		$this->assertTrue($method->isStatic(), 'Method create() exists but is not static');
	}

	public function testSessionContainerCreated() : void
	{
		SessionManager::create();
		$this->assertArrayHasKey('container', $_SESSION);
		$this->assertIsArray($_SESSION['container']);
	}
}

?>