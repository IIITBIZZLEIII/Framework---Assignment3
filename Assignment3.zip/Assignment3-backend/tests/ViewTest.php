<?php

use PHPUnit\Framework\TestCase;
require 'framework/View.php';

class ViewTest extends TestCase
{
	//checks if the view class object exists
	public function testViewObjectExist() : void
	{
		$this->assertIsObject(new View);
	}
	//checks if the setTemplate 
	public function testViewMethodSetTemplate() : void 
	{
		$this->assertNotEmpty('setTemplate',"the setTemplate method is empty");
		$this->assertIsString('$tpl',"is not a string");
		
	}

	public function testViewMethoddisplay() : void
	{
		$this->assertNotEmpty('display',"the display method is empty");
	}

	public function testViewMethodaddVar() : void
	{
		$this->assertNotEmpty('addVar',"addVar is empty");
		$this->assertIsString('$vari',"tpl is not empty");
	}
}
?>